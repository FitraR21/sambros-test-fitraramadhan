<!DOCTYPE html>
    <html>
        <head>
            <title>Form PIC</title>
            <script src="js/jquery.js"></script>
            <script>
                //mengidentifikasikan variabel yang kita gunakan
                var nama;
                var phone;
                var address;
                var logo;
				var pics;
                $(function(){
                 
                    $("#pic").load("proses.php","op=pic");
                    //jika ada perubahan di nama
                    $("#nama").change(function(){
                        nama=$("#nama").val();
                 
                        
                        //tampilkan status loading dan animasinya
                        $("#status").html("loading. . .");
                        $("#loading").show();
                        
                        //lakukan pengiriman data
                        $.ajax({
                            url:"proses.php",
                            data:"op=ambildata&nama="+nama,
                            cache:false,
                            success:function(msg){
                                data=msg.split("|");
                                
                                //masukan isi data ke masing - masing field
                                $("#nama").val(data[0]);
                                $("#phone").val(data[1]);
                                $("#address").val(data[2]);
                                $("#logo").val(data[3]);
                                $("#pics").val(data[4]);
                                
                                //hilangkan status animasi dan loading
                                $("#status").html("");
                                $("#loading").hide();
                            }
                        });
                    });
                    
                    //cek nama yang sudah ada
                    $("#nama2").change(function(){
                        var kd=$("#nama2").val();
                        
                        $.ajax({
                            url:"proses.php",
                            data:"op=cek&kd="+kd,
                            success:function(data){
                                if(data==0){
                                    $("#pesan").html('Nama Bisa digunakan');
                                    $("#nama2").css('border','3px #090 solid');
                                }else{
                                    $("#pesan").html('Nama sudah ada');
                                    $("#nama2").css('border','3px #c33 solid');
                                }
                            }
                        });
                    });
                    
                    //ketika tombol update di klik
                    $("#update").click(function(){
                        //cek  kosong atau tidak
                        nama=$("#nama").val();
                        if(nama=="nama"){
                            alert("Pilih Nama dulu");
                            exit();
                        }
                        nama=$("#phone").val();
                        beli=$("#address").val();
                        jual=$("#logo").val();
                        stok=$("#pics").val();
                        
                        //tampilkan status update
                        $("#status").html('sedang diupdate. . .');
                        $("#loading").show();
                        
                        $.ajax({
                            url:"proses.php",
                            data:"op=update&nama="+nama+"&phone="+phone+"&logo="+logo+"&pics="+pics,
                            cache:false,
                            success:function(msg){
                                if(msg=='Sukses'){
                                    $("#status").html('Update Berhasil. . .');
                                }else{
                                    $("#status").html('ERROR. . .')
                                }
                                $("#loading").hide();
                                $("#phone").val("");
                                $("#address").val("");
                                $("#logo").val("");
                                $("#pics").val("");
                                $("#pic").load("proses.php","op=pic");
                                $("#nama").load("proses.php","op=nama");
                            }
                        });
                    });
                    
                    //ketika tombol hapus diklik
                    $("#hapus").click(function(){
                        nama=$("#nama").val();
                        if(nama=="Nama"){
                            alert("Nama belum dipilih");
                            exit();
                        }
                        $("#status").html('Sedang Dihapus. . .');
                        $("#loading").show();
                        
                        $.ajax({
                            url:"proses.php",
                            data:"op=delete&nama="+nama,
                            cache:false,
                            success:function(msg){
                                if(msg=="sukses"){
                                    $("#status").html('Berhasil Dihapus. . .');
                                }else{
                                    $("#status").html('ERROR. . .');
                                }
                                $("#phone").val("");
                                $("#adress").val("");
                                $("#logo").val("");
                                $("#pics").val("");
                                $("#pic").load("proses.php","op=pic");
                                $("#nama").load("proses.php","op=nama");
                                
                            }
                        });
                    });
                    
                    //ketika tombol simpan diklik
                    $("#simpan").click(function(){
                        nama=$("#nama2").val();
                        if(nama==""){
                            alert("Nama Harus diisi");
                            exit();
                        }
                        phone=$("#phone").val();
                        address=$("#address").val();
                        logo=$("#logo").val();
                        pics=$("#pics").val();
                        
                        $("#status").html("sedang diproses. . .");
                        $("#loading").show();
                        
                        $.ajax({
                            url:"proses.php",
                            data:"op=simpan&nama="+nama+"&phone="+phone+"&logo="+logo+"&pics="+pics+,
                            cache:false,
                            success:function(msg){
                                if(msg=="sukses"){
                                    $("#status").html("Berhasil disimpan. . .");
                                }else{
                                    $("#status").html("ERROR. . .");
                                }
                                $("#loading").hide();
                                $("#phone").val("");
                                $("#address").val("");
                                $("#logo").val("");
                                $("#pics").val("");
                                $("#nama2").val("");
                            }
                        });
                    });
                });
            </script>
        </head>
        <body>
            <?php
            $p=isset($_GET['act'])?$_GET['act']:null;
            switch($p){
                default:
                    echo'
                        <legend>Data PIC</legend>
                       
                        <input type="text" id="nama" placeholder="Nama" class="span2">
                        <input type="text" id="phone" placeholder="Phone Number" class="span2">
                        <input type="text" id="address" placeholder="Addres" class="span2">
                        <input type="text" id="logo" placeholder="Logo" class="span1">
						<input type="text" id="pics" placeholder="PIC" class="span1">
                        <button id="update" class="btn">Update</button>
                        <button id="hapus" class="btn">Hapus</button>
                    <div id="status"></div><br>
                    <div id="barang"></div>';
                    break;
                case "tambah":
                        echo'<legend>Tambah Data PIC</legend>
                        <label>Nama</label>
                            <input type="text" id="nama"> <span id="pesan"></span>
                        <label>Phone Number</label>
                            <input type="text" id="phone" >
                        <label>Address</label>
                            <input type="text" id="address" >
                        <label>Logo</label>
                            <input type="text" id="logo" >
                        <label>PIC</label>
                            <input type="text" id="pic" class="span1">
                        <label></label>
                        <button id="simpan" class="btn">Simpan</button>
                        <a href="?page=barang" class="btn">Kembali</a>
                        <div id="status"></div>';
                    break;
            }
            ?>
        </body>
    </html>
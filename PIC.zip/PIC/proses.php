<?php
include "db/koneksi.php";
$data=mysql_query("select * from pic");
$op=isset($_GET['op'])?$_GET['op']:null;

if($op=='nama'){
    echo"<option>Nama</option>";
    while($r=mysql_fetch_array($data)){
        echo "<option value='$r[nama]'>$r[nama]</option>";
    }
}elseif($op=='pic'){
    echo'<table id="pic" class="table table-hover">
    <thead>
            <tr>
                <Td colspan="5"><a href="?page=pic&act=tambah" class="btn btn-primary">Tambah Data</a></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>Phone Number</td>
                <td>Address</td>
                <td>Logo</td>
                <td>PIC</td>
            </tr>
        </thead>';
	while ($b=mysql_fetch_array($data)){
        echo"<tr>
                <td>$b[nama]</td>
                <td>$b[phone]</td>
                <td>$b[address]</td>
                <td>$b[logo]</td>
                <td>$b[pics]</td>
            </tr>";
        }
    echo "</table>";
}elseif($op=='ambildata'){
    $nama=$_GET['nama'];
    $dt=mysql_query("select * from fitra where nama='$nama'");
    $d=mysql_fetch_array($dt);
    echo $d['nama']."|".$d['phone']."|".$d['address']."|".$d['logo']."|".$d['pics'];
}elseif($op=='cek'){
    $kd=$_GET['kd'];
    $sql=mysql_query("select * from fitra where nama='$kd'");
    $cek=mysql_num_rows($sql);
    echo $cek;
}elseif($op=='update'){
    $nama=$_GET['nama'];
    $phone=htmlspecialchars($_GET['phone']);
    $address=htmlspecialchars($_GET['address']);
    $logo=htmlspecialchars($_GET['logo']);
    $pics=htmlspecialchars($_GET['pics']);
    
    $update=mysql_query("update fitra set phone='$phone',
                        address='$address',
                        logo='$logo'
                        where nama='$nama'");
    if($update){
        echo "Sukses";
    }else{
        echo "ERROR. . .";
    }
}elseif($op=='delete'){
    $nama=$_GET['nama'];
    $del=mysql_query("delete from fitra where nama='nama'");
    if($del){
        echo "sukses";
    }else{
        echo "ERROR";
    }
}elseif($op=='simpan'){
    $nama=$_GET['nama'];
    $phone=htmlspecialchars($_GET['phone']);
    $address=htmlspecialchars($_GET['address']);
    $logo=htmlspecialchars($_GET['logo']);
    $pics=htmlspecialchars($_GET['pics']);
    
    $tambah=mysql_query("insert into fitra (nama,phone,address,logo,pics)
                        values ('$nama','$phone','$address','$logo','$pics')");
    if($tambah){
        echo "sukses";
    }else{
        echo "error";
    }
}
?>